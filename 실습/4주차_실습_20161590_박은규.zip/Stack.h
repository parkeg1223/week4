#include "LinkedList.h"

template <typename T>
class Stack : public LinkedList<T> {
	public:
		virtual bool Delete(T &element);
};

template <typename T>
bool Stack<T>::Delete(T &element) {
	if(this->first == 0) return false;
	Node<T> *tmp = this->first;
	element = this->first->data;
	this->first = this->first->link;
	delete tmp;
	this->current_size--;
	return true;
}
